﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using Microgroove_Challenge.RecordTypes;

namespace Microgroove_Challenge
{
    public class FileRecordsParser
    {
        public static string ParseCSVRecords(string[] fileRecords)
        {
            // As the code challenge states, there's only one file record, and one end record.
            FileRecord fileRecord = new FileRecord();
            EndRecord endRecord = new EndRecord();

            // Looping through each record, we will populate the fileRecord object with the given data.
            for (int i = 0; i < fileRecords.Length; i++)
            {
                fileRecords[i] = fileRecords[i].Replace("\"", "");
                fileRecords[i] = fileRecords[i].Replace(@"\", "");
                fileRecords[i] = fileRecords[i].Trim();
            }
            foreach (string record in fileRecords)
            {

                // Assuming that those records have fixed fields, we develop a static reading of their values.
                string[] recordStrings = record.Split(",");
                if (recordStrings[0].Contains("F"))
                {
                    fileRecord.Date = recordStrings[1];
                    fileRecord.Note = recordStrings[2];
                }

                if (recordStrings[0].Contains("O"))
                {
                    OrderRecord orderRecord = new OrderRecord()
                    {
                        OrderId = recordStrings[1],
                        OrderDate = recordStrings[2],
                        OnfNumber = recordStrings[3],
                        OrderRelatedText = recordStrings[4]
                    };

                    fileRecord.orderRecords.Add(orderRecord);
                }

                if (recordStrings[0].Contains("B"))
                {
                    BRecord bRecord = new BRecord()
                    {
                        Name = recordStrings[1],
                        Address = recordStrings[2],
                        ZipCode = recordStrings[3],
                        OrderId = recordStrings[4]
                    };

                    var orderUpdatedWithBRecord = fileRecord.orderRecords.Find(x => x.OrderId == bRecord.OrderId);
                    orderUpdatedWithBRecord.BRecord = bRecord;
                }

                if (recordStrings[0].Contains("L"))
                {
                    LineItemRecord lineItemRecord = new LineItemRecord()
                    {
                        LineItemNumber = recordStrings[1],
                        ItemId = recordStrings[2],
                        OrderId = recordStrings[3]
                    };

                    var orderUpdatedWithLRecord = fileRecord.orderRecords.Find(x => x.OrderId == lineItemRecord.OrderId);
                    orderUpdatedWithLRecord.LineItemRecords.Add(lineItemRecord);
                }

                if (recordStrings[0].Contains("T"))
                {
                    TRecord tRecord = new TRecord()
                    {
                        fieldOne = recordStrings[1],
                        fieldTwo = recordStrings[2],
                        fieldThree = recordStrings[3],
                        fieldFour = recordStrings[4],
                        fieldFive = recordStrings[5],
                        OrderId = recordStrings[6]
                    };

                    var orderUpdatedWithTRecord = fileRecord.orderRecords.Find(x => x.OrderId == tRecord.OrderId);
                    orderUpdatedWithTRecord.TRecord = tRecord;
                }

                if (recordStrings[0].Contains("E"))
                {
                    endRecord.FieldOne = recordStrings[1];
                    endRecord.FieldTwo = recordStrings[2];
                    endRecord.FieldThree = recordStrings[3];
                    fileRecord.endRecord = endRecord;
                }
            }

            string json = JsonConvert.SerializeObject(fileRecord);
            return json;
        }
    }
}
