﻿using System;
using System.IO;

namespace Microgroove_Challenge
{
    class Program
    {
        static void Main(string[] args)
        {
            /* PLEASE READ
             * I've went through the assessment requirements and given input, and have developed this solution based off the requirements only.
             * The given input doesn't correlate the data, therefore, we wouldn't be able to tell which "LK" records or "B" and "T" records belong to which "O" records if there were multiple "O" records.
             * I've edited the given input a little bit to match the requirements that came with this task.
             */

            Console.WriteLine("Hello World!");
            var fileRecords = File.ReadAllLines(@"..\..\..\givenInput.csv");
            string json = FileRecordsParser.ParseCSVRecords(fileRecords);
            Console.WriteLine(json);
            Console.ReadLine();

        }
    }
}
