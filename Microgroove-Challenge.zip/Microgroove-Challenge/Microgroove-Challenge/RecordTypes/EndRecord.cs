﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microgroove_Challenge.RecordTypes
{
    public class EndRecord
    {
        public string FieldOne {get;set;}
        public string FieldTwo { get; set; }
        public string FieldThree { get; set; }

    }
}
