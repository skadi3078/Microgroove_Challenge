﻿using System;
using System.Collections.Generic;
using System.Text;
using Microgroove_Challenge.RecordTypes;

namespace Microgroove_Challenge
{
    public class FileRecord
    {
        public string recordType = "FileRecord";
        public string Date { get; set; }
        public string Note { get; set; }
        public FileRecord()
        {
            orderRecords = new List<OrderRecord>();
        }
        public List<OrderRecord> orderRecords { get; set; }

        public EndRecord endRecord { get; set; }

    }
}
