﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microgroove_Challenge
{
    public class LineItemRecord
    {
        public string LineItemNumber { get; set; }
        public string ItemId { get; set; }
        public string OrderId { get; set; }
    }
}
