﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microgroove_Challenge
{
    public class TRecord
    {
        public string fieldOne { get; set; }
        public string fieldTwo { get; set; }
        public string fieldThree { get; set; }
        public string fieldFour { get; set;}
        public string fieldFive { get; set; }
        public string OrderId { get; set; }
    }
}
