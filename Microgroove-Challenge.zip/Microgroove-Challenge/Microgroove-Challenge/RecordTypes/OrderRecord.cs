﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microgroove_Challenge
{
    public class OrderRecord
    {
        public OrderRecord()
        {
            BRecord = new BRecord();
            TRecord = new TRecord();
            LineItemRecords = new List<LineItemRecord>();
        }
        public string OrderId { get; set; }
        public string OrderDate { get; set; }
        public string OnfNumber { get; set; }
        // I can't tell much based off the given input. So I named it related text.
        public string OrderRelatedText { get; set; }
        public BRecord BRecord {get; set; }
        public TRecord TRecord { get; set; }
        public List<LineItemRecord> LineItemRecords { get; set; }


    }
}
